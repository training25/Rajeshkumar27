"""
System Configuration Module for Privacy-Preserved Dual-Blockchain Crowdsourcing in SDNs.
Defines parameters for:
- Dual Blockchain (Sensing Chain SC & Reputation Chain RC)
- Local-Node f-Differential Privacy (f-DP)
- Dynamic Reputation Management
- Decentralized Federated Reinforcement Learning (DFRL)
- Software-Defined Networking (SDN) Crowdsourcing Overlay
- Regulatory Authority Consent
"""

from dataclasses import dataclass, field
from typing import Dict, List, Tuple


@dataclass
class FDifferentialPrivacyConfig:
    """Configuration for Local-node f-Differential Privacy (f-DP)."""
    epsilon: float = 1.0                  # Primary privacy budget epsilon
    delta: float = 1e-5                   # Privacy parameter delta
    sensitivity: float = 1.0              # L2 global sensitivity
    clipping_bound: float = 5.0           # Gradient/data clipping threshold
    noise_mechanism: str = "gaussian"     # Gaussian trade-off function implementation
    sigma: float = 1.25                   # Calibrated Gaussian noise scale sigma


@dataclass
class DualBlockchainConfig:
    """Configuration for Dual-Blockchain Architecture (SC & RC)."""
    # Sensing Chain (SC) - Public Layer
    sc_name: str = "Sensing_Chain_Public"
    sc_block_time_sec: float = 0.5
    sc_max_tx_per_block: int = 64
    
    # Reputation Chain (RC) - Consortium Ethereum Layer
    rc_name: str = "Reputation_Chain_Consortium"
    rc_block_time_sec: float = 1.0
    rc_max_tx_per_block: int = 128
    
    consensus_type: str = "PoA"           # Proof of Authority / Consortium Raft
    num_consortium_validators: int = 5
    challenge_timeout_sec: float = 5.0


@dataclass
class DynamicReputationConfig:
    """Configuration for Dynamic Reputation Scoring."""
    initial_reputation: float = 0.50      # Default starting reputation
    min_reputation_threshold: float = 0.30# Below this worker is restricted
    max_reputation: float = 1.0
    decay_factor: float = 0.98            # Time-decay factor for historical reputation
    consistency_weight: float = 0.40      # Weight for multi-worker consensus consistency
    quality_weight: float = 0.35          # Weight for data accuracy / SNR
    timeliness_weight: float = 0.25       # Weight for low latency submission
    malicious_penalty_multiplier: float = 2.5


@dataclass
class SDNNetworkConfig:
    """Configuration for SDN Wireless Area Crowdsourcing Network."""
    num_workers: int = 40                 # Distributed mobile crowdsensing workers
    num_task_publishers: int = 5          # Service providers / consumers
    num_sdn_switches: int = 6
    bandwidth_capacity_mbps: float = 100.0
    base_latency_ms: float = 14.0
    jitter_ms: float = 3.2
    base_loss_rate: float = 0.012         # 1.2% base packet loss
    max_queue_depth: int = 400


@dataclass
class DFRLConfig:
    """Configuration for Decentralized Federated Reinforcement Learning."""
    num_states: int = 16
    num_actions: int = 4                  # SDN routing paths / task bidding modes
    learning_rate: float = 0.08
    discount_factor: float = 0.95
    exploration_epsilon: float = 0.20
    epsilon_decay: float = 0.992
    min_epsilon: float = 0.02
    federated_rounds: int = 25
    local_epochs: int = 4
    num_clients: int = 6                  # SDN edge controllers / cluster heads


@dataclass
class RegulatoryConsentConfig:
    """Configuration for Government / Regulatory Authority Access Management."""
    authority_name: str = "National_Data_Governance_Commission"
    compliance_standards: List[str] = field(default_factory=lambda: ["GDPR", "HIPAA", "NIST_SP_800_53"])
    audit_interval_sec: float = 10.0
    consent_expiry_hours: float = 24.0


@dataclass
class SystemConfig:
    """Master Unified Configuration for Dual-Blockchain Crowdsourcing."""
    fdp: FDifferentialPrivacyConfig = field(default_factory=FDifferentialPrivacyConfig)
    blockchain: DualBlockchainConfig = field(default_factory=DualBlockchainConfig)
    reputation: DynamicReputationConfig = field(default_factory=DynamicReputationConfig)
    sdn: SDNNetworkConfig = field(default_factory=SDNNetworkConfig)
    dfrl: DFRLConfig = field(default_factory=DFRLConfig)
    authority: RegulatoryConsentConfig = field(default_factory=RegulatoryConsentConfig)
    random_seed: int = 42
    results_dir: str = "C:/work/Rajesh Paper 27_PC/results"


def get_default_config() -> SystemConfig:
    """Helper to return an instance of master configuration."""
    return SystemConfig()
