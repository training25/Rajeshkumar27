"""
Software-Defined Networking (SDN) Crowdsourcing Environment.
Models SDN controller, virtual forwarding switches, dynamic fluctuating wireless links,
flow routing, priority queuing, and packet delivery dynamics.
"""

import time
import math
import numpy as np
from typing import Dict, List, Any, Tuple, Optional
from config.system_config import SDNNetworkConfig


class SDNSwitch:
    """Represents an OpenFlow-compatible virtual forwarding switch in SD-WAN."""
    def __init__(self, switch_id: str, capacity_mbps: float = 100.0):
        self.switch_id = switch_id
        self.capacity_mbps = capacity_mbps
        self.active_load_mbps = 0.0
        self.queue_depth = 0
        self.flow_rules: Dict[str, str] = {}
        self.is_congested = False

    def update_load(self, load_mbps: float):
        self.active_load_mbps = max(0.0, load_mbps)
        load_ratio = self.active_load_mbps / (self.capacity_mbps + 1e-6)
        self.queue_depth = int(load_ratio * 300)
        self.is_congested = (load_ratio > 0.75)


class SDNCrowdsourcingNetwork:
    """
    SDN Overlay Environment for crowdsourcing data sharing.
    Provides centralized global network visibility and adaptive flow forwarding.
    """
    def __init__(self, config: Optional[SDNNetworkConfig] = None, seed: int = 42):
        self.config = config or SDNNetworkConfig()
        self.rng = np.random.RandomState(seed)
        self.step_counter = 0

        # Initialize 4 distinct SDWAN routing paths:
        # Path 0: High-Speed SDN Fiber Core (Low delay, low loss, high capacity)
        # Path 1: Multi-hop Wireless Mesh Link (Moderate delay, fluctuating loss)
        # Path 2: 5G Sliced Edge Channel (Optimized for fast-track verified tasks)
        # Path 3: Public Internet Tunnel (Higher delay, baseline fallback)
        self.paths: Dict[int, Dict[str, Any]] = {
            0: {"name": "SDN_Fiber_Core", "base_lat": 8.5, "loss_base": 0.005, "capacity": 150.0, "current_lat": 8.5, "current_loss": 0.005, "load": 20.0},
            1: {"name": "Wireless_Mesh_Overlay", "base_lat": 19.0, "loss_base": 0.015, "capacity": 100.0, "current_lat": 19.0, "current_loss": 0.015, "load": 30.0},
            2: {"name": "5G_Edge_Slice", "base_lat": 12.0, "loss_base": 0.008, "capacity": 120.0, "current_lat": 12.0, "current_loss": 0.008, "load": 15.0},
            3: {"name": "Public_WAN_Fallback", "base_lat": 42.0, "loss_base": 0.030, "capacity": 50.0, "current_lat": 42.0, "current_loss": 0.030, "load": 10.0}
        }

        # Initialize virtual SDN switches
        self.switches: Dict[str, SDNSwitch] = {
            f"SW_{i}": SDNSwitch(f"SW_{i}", capacity_mbps=self.config.bandwidth_capacity_mbps)
            for i in range(self.config.num_sdn_switches)
        }

    def step_environment(self):
        """Simulates wireless link fluctuation, traffic surges, and queue shifts."""
        self.step_counter += 1
        t = self.step_counter * 0.1

        for pid, p in self.paths.items():
            noise = float(self.rng.normal(0, 1))
            # Simulated crowdsourcing traffic oscillation
            traffic_load = 25.0 + 15.0 * math.sin(t + pid) + abs(self.rng.normal(0, 6))
            p["load"] = max(5.0, min(p["capacity"] * 0.95, traffic_load))

            load_ratio = p["load"] / p["capacity"]
            congestion_penalty = (load_ratio ** 2.2) * 35.0 if load_ratio > 0.70 else (load_ratio * 4.0)

            p["current_lat"] = max(3.0, p["base_lat"] + congestion_penalty + noise * 1.5)
            loss_spike = 0.04 * max(0.0, load_ratio - 0.75)
            p["current_loss"] = float(np.clip(p["loss_base"] + loss_spike + abs(noise * 0.003), 0.0, 0.35))

    def forward_crowdsourced_packet(
        self,
        packet_size_bytes: int,
        path_id: int,
        worker_reputation: float,
        is_authenticated: bool
    ) -> Dict[str, Any]:
        """
        Forwards a sensing data packet through the chosen SDN path.
        High-reputation workers benefit from SDN priority queuing.
        """
        p = self.paths.get(path_id, self.paths[1])

        # Priority queue delay reduction for trusted participants
        reputation_bonus = max(0.2, worker_reputation)
        effective_queue_delay = (p["load"] * 0.25) / reputation_bonus

        tx_delay = (packet_size_bytes * 8.0) / (p["capacity"] * 1e6) * 1000.0 # ms
        total_delay = p["current_lat"] + effective_queue_delay + tx_delay

        # Packet drop event
        loss_chance = p["current_loss"] * (1.2 - 0.4 * worker_reputation)
        dropped = (self.rng.rand() < loss_chance) or (not is_authenticated)

        util_pct = min(100.0, (p["load"] / p["capacity"]) * 100.0)

        return {
            "path_id": path_id,
            "path_name": p["name"],
            "total_delay_ms": round(float(total_delay), 2),
            "dropped": bool(dropped),
            "bandwidth_utilization_pct": round(float(util_pct), 2),
            "loss_prob": round(float(loss_chance), 4)
        }

    def get_network_state_vector(self) -> np.ndarray:
        """Returns continuous state vector of all path latencies and loads for DFRL."""
        state = []
        for pid in sorted(self.paths.keys()):
            p = self.paths[pid]
            state.extend([p["current_lat"] / 100.0, p["current_loss"], p["load"] / p["capacity"]])
        return np.array(state, dtype=np.float32)
