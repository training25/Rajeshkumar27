"""
Crowdsourcing Sensing Dataset & Cybersecurity Threat Stream Generator.
Simulates realistic urban IoT sensing scenarios (Air Quality, Noise, Traffic Speed)
and adversarial cyberattacks (Data Poisoning, Sybil, Unauthorized Access, Replay).
"""

import time
import math
import numpy as np
from typing import Dict, List, Any, Tuple, Optional


CROWDSENSING_TASK_TYPES = [
    {"type": "URBAN_AIR_QUALITY", "dims": ["PM2.5", "PM10", "NO2", "CO", "O3"], "mean": [28.5, 55.0, 32.0, 1.2, 45.0], "std": [6.0, 12.0, 8.0, 0.3, 10.0]},
    {"type": "SMART_CITY_ACOUSTIC_NOISE", "dims": ["Leq_dB", "Lpeak_dB", "L10_dB", "L90_dB"], "mean": [62.0, 85.0, 68.0, 52.0], "std": [8.0, 10.0, 7.0, 5.0]},
    {"type": "ROAD_TRAFFIC_SPEED", "dims": ["AvgSpeed_kmh", "VehicleFlow_min", "Occupancy_pct"], "mean": [42.0, 35.0, 28.0], "std": [12.0, 10.0, 15.0]}
]

ATTACK_CATEGORIES = [
    "BENIGN_NORMAL",
    "DATA_POISONING_ATTACK",
    "SYBIL_IDENTITY_ATTACK",
    "UNAUTHORIZED_ACCESS_ATTACK",
    "CROSS_CHAIN_REPLAY_ATTACK"
]


class CrowdsourcingDataGenerator:
    """
    Generates realistic mobile crowdsensing streams and adversarial attack vectors
    for testing the privacy, reputation, and security mechanisms of the framework.
    """
    def __init__(self, seed: int = 42):
        self.rng = np.random.RandomState(seed)
        self.sample_idx = 0

    def generate_sensing_vector(self, task_spec: Dict[str, Any], is_poisoned: bool = False) -> np.ndarray:
        """Generates multi-sensor reading array with optional poisoned distortion."""
        mean_v = np.array(task_spec["mean"], dtype=np.float32)
        std_v = np.array(task_spec["std"], dtype=np.float32)

        if not is_poisoned:
            noise = self.rng.normal(0, 1, size=len(mean_v))
            vec = mean_v + noise * std_v
        else:
            # Extreme malicious distortion (poisoning urban aggregation)
            vec = mean_v * self.rng.uniform(3.5, 6.0) + self.rng.uniform(100.0, 300.0)

        return np.maximum(vec, 0.0)

    def generate_simulation_stream(
        self,
        num_tasks: int = 50,
        submissions_per_task: int = 6,
        attack_ratio: float = 0.25
    ) -> List[Dict[str, Any]]:
        """
        Generates a chronological sequence of crowdsensing tasks and worker submissions.
        """
        stream = []
        total_submissions = num_tasks * submissions_per_task
        num_attacks = int(total_submissions * attack_ratio)
        attack_flags = [0] * (total_submissions - num_attacks) + [1] * num_attacks
        self.rng.shuffle(attack_flags)

        global_sub_idx = 0

        for t_idx in range(num_tasks):
            task_meta = self.rng.choice(CROWDSENSING_TASK_TYPES)
            task_id = f"TASK_{t_idx+1:04d}"
            publisher_id = f"PUBLISHER_{self.rng.randint(1, 5):02d}"
            min_rep = float(self.rng.uniform(0.35, 0.55))
            reward = float(self.rng.uniform(5.0, 20.0))

            task_ground_truth = self.generate_sensing_vector(task_meta, is_poisoned=False)

            task_obj = {
                "task_id": task_id,
                "publisher_id": publisher_id,
                "task_type": task_meta["type"],
                "min_reputation": round(min_rep, 2),
                "reward_tokens": round(reward, 1),
                "ground_truth": task_ground_truth,
                "submissions": []
            }

            for s_idx in range(submissions_per_task):
                is_attack = bool(attack_flags[global_sub_idx])
                global_sub_idx += 1
                self.sample_idx += 1

                worker_num = self.rng.randint(1, 40)
                real_worker_id = f"WORKER_{worker_num:03d}"
                pseudo_worker_id = f"PSEUDO_{real_worker_id}_SESS_{t_idx}"

                if not is_attack:
                    attack_type = "BENIGN_NORMAL"
                    is_poisoned = False
                    has_consent = True
                    is_sybil = False
                else:
                    attack_type = str(self.rng.choice(ATTACK_CATEGORIES[1:]))
                    is_poisoned = (attack_type == "DATA_POISONING_ATTACK")
                    has_consent = (attack_type != "UNAUTHORIZED_ACCESS_ATTACK")
                    is_sybil = (attack_type == "SYBIL_IDENTITY_ATTACK")
                    if is_sybil:
                        pseudo_worker_id = f"SYBIL_GHOST_{self.rng.randint(900, 999):03d}"

                raw_vector = self.generate_sensing_vector(task_meta, is_poisoned=is_poisoned)

                sub_item = {
                    "sub_id": f"SUB_{self.sample_idx:06d}",
                    "task_id": task_id,
                    "task_meta": task_meta,
                    "real_worker_id": real_worker_id,
                    "pseudo_worker_id": pseudo_worker_id,
                    "raw_vector": raw_vector,
                    "is_attack": int(is_attack),
                    "attack_type": attack_type,
                    "is_poisoned": is_poisoned,
                    "is_sybil": is_sybil,
                    "has_consent": has_consent,
                    "timestamp": time.time()
                }
                task_obj["submissions"].append(sub_item)

            stream.append(task_obj)

        return stream
