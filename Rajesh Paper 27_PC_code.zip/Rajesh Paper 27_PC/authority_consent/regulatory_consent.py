"""
Regulatory Authority & Automated Consent Management Module.
Implements government authority governance, automated cryptographic consent tokens,
regulatory compliance audits, and authorized de-anonymization for malicious entities.
"""

import time
import json
import hashlib
from typing import Dict, List, Any, Tuple, Optional
from config.system_config import RegulatoryConsentConfig


def sha256_hash(data: str) -> str:
    return hashlib.sha256(data.encode('utf-8')).hexdigest()


class RegulatoryConsentManager:
    """
    Government / Regulatory Authority Governance Node.
    Ensures data sharing requests have verifiable legal basis, automated consent,
    and auditability under compliance regulations (GDPR, HIPAA, NIST).
    """
    def __init__(self, config: Optional[RegulatoryConsentConfig] = None):
        self.config = config or RegulatoryConsentConfig()
        self.authority_name = self.config.authority_name
        self.authority_private_key = sha256_hash(f"AUTH_PRIV_{self.authority_name}")
        self.authority_pubkey = sha256_hash(f"AUTH_PUB_{self.authority_private_key}")

        # Active consent tokens registry: {token_id: token_dict}
        self.issued_consent_tokens: Dict[str, Dict[str, Any]] = {}
        # Audit log of all data access queries
        self.audit_access_log: List[Dict[str, Any]] = []

    def issue_data_access_consent(
        self,
        requester_id: str,
        requester_role: str,
        target_dataset_id: str,
        access_purpose: str,
        worker_reputation: float
    ) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """
        Evaluates requester legitimacy and participant reputation before issuing
        a cryptographically signed automated consent token.
        """
        # Minimum trust gate for data consumers
        if worker_reputation < 0.40 and requester_role != "authority_auditor":
            return False, "Consent Denied: Trust score insufficient for sensitive data access.", None

        valid_until = time.time() + (self.config.consent_expiry_hours * 3600.0)
        token_id = f"CONSENT_{sha256_hash(f'{requester_id}_{target_dataset_id}_{time.time()}')[:16]}"

        raw_signature_payload = f"{token_id}_{requester_id}_{target_dataset_id}_{valid_until}_{self.authority_private_key}"
        token_signature = sha256_hash(raw_signature_payload)

        token = {
            "token_id": token_id,
            "issuer": self.authority_name,
            "requester_id": requester_id,
            "requester_role": requester_role,
            "target_dataset_id": target_dataset_id,
            "access_purpose": access_purpose,
            "issued_at": time.time(),
            "valid_until": valid_until,
            "signature": token_signature,
            "compliance_standards": self.config.compliance_standards,
            "is_revoked": False
        }

        self.issued_consent_tokens[token_id] = token
        return True, "Automated Consent Token Issued by Regulatory Authority.", token

    def verify_consent_token(self, token_id: str, requester_id: str, dataset_id: str) -> bool:
        """Verifies digital signature and active validity of a consent token."""
        if token_id not in self.issued_consent_tokens:
            return False

        t = self.issued_consent_tokens[token_id]
        if t["is_revoked"] or time.time() > t["valid_until"]:
            return False

        if t["requester_id"] != requester_id or t["target_dataset_id"] != dataset_id:
            return False

        # Verify signature
        expected_sig = sha256_hash(f"{t['token_id']}_{t['requester_id']}_{t['target_dataset_id']}_{t['valid_until']}_{self.authority_private_key}")
        return t["signature"] == expected_sig

    def audit_access_event(
        self,
        requester_id: str,
        resource_id: str,
        access_granted: bool,
        token_id: Optional[str] = None
    ):
        """Records an immutable audit event of data query for transparency."""
        entry = {
            "audit_id": f"AUDIT_{len(self.audit_access_log)+1:06d}",
            "requester_id": requester_id,
            "resource_id": resource_id,
            "access_granted": access_granted,
            "token_id": token_id,
            "timestamp": time.time()
        }
        self.audit_access_log.append(entry)

    def authorize_de_anonymization(
        self,
        pseudo_id: str,
        reputation_chain_mapping: Dict[str, str],
        court_warrant_id: str
    ) -> Tuple[bool, str]:
        """
        Regulatory oversight mechanism:
        Allows deanonymization of persistent threat actors (e.g. Sybil ring leader)
        with an official audit warrant.
        """
        if not court_warrant_id.startswith("WARRANT_"):
            return False, "De-anonymization Denied: Invalid judicial warrant."

        if pseudo_id in reputation_chain_mapping:
            real_id = reputation_chain_mapping[pseudo_id]
            return True, f"Authority De-anonymized Entity -> Real ID: {real_id}"
        return False, "Pseudo-ID not found in consortium mapping registry."
