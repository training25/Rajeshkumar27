"""
Smart Contracts for Dual-Blockchain Crowdsourcing Framework.
1. Task Management Contract (Sensing Chain)
2. Reputation Smart Contract (Reputation Chain)
3. Access Control & Authorization Contract (Cross-Chain)
"""

import time
import json
import hashlib
from typing import Dict, List, Any, Tuple, Optional, Set


def sha256_hash(data: str) -> str:
    return hashlib.sha256(data.encode('utf-8')).hexdigest()


class DualSmartContractEngine:
    """
    Virtual Ethereum Virtual Machine (EVM) / Smart Contract execution runtime.
    Validates state transitions, enforces access policies, and measures execution latency.
    """
    def __init__(self):
        # Access control lists
        self.authorized_roles: Dict[str, Set[str]] = {
            "task_publisher": {"PUBLISH_TASK", "VIEW_AGGREGATED_DATA", "QUERY_TASK_STATUS"},
            "sensing_worker": {"BID_TASK", "SUBMIT_DATA", "QUERY_OWN_REPUTATION"},
            "authority_auditor": {"AUDIT_LOGS", "DE_ANONYMIZE_THREAT", "REVOKE_WORKER", "ACCESS_ALL_CONSENTED"},
            "sdn_controller": {"ROUTE_TASK", "ALLOCATE_BANDWIDTH", "CROSS_CHAIN_QUERY"}
        }

        # Registered access tokens
        self.access_tokens: Dict[str, Dict[str, Any]] = {}
        # Threat audit log
        self.threat_audit_log: List[Dict[str, Any]] = []

        # Performance counters
        self.total_invocations = 0
        self.total_execution_time_ms = 0.0

    def verify_role_permission(self, caller_role: str, action: str) -> bool:
        """Checks if caller role has permission for given action."""
        if caller_role in self.authorized_roles:
            return action in self.authorized_roles[caller_role]
        return False

    def validate_task_bid(
        self,
        worker_pseudo_id: str,
        task_id: str,
        worker_reputation: float,
        task_min_reputation: float
    ) -> Tuple[bool, str, float]:
        """
        Smart contract evaluation: Validates worker bid against task reputation threshold.
        """
        t0 = time.perf_counter()
        self.total_invocations += 1

        if worker_reputation < task_min_reputation:
            exec_time = (time.perf_counter() - t0) * 1000.0
            self.total_execution_time_ms += exec_time
            self._record_threat(worker_pseudo_id, "BID_REPUTATION_INSUFFICIENT", f"Reputation {worker_reputation:.2f} < threshold {task_min_reputation:.2f}")
            return False, f"Bid Rejected: Worker reputation ({worker_reputation:.2f}) does not meet task requirement ({task_min_reputation:.2f}).", exec_time

        exec_time = (time.perf_counter() - t0) * 1000.0
        self.total_execution_time_ms += exec_time
        return True, "Bid Accepted by Smart Contract: Worker reputation verified.", exec_time

    def evaluate_access_authorization(
        self,
        requester_id: str,
        requester_role: str,
        resource_id: str,
        has_authority_consent: bool = True
    ) -> Tuple[bool, str, float]:
        """
        Enforces access control policies for reading crowdsourced dataset.
        Requires valid role and regulatory consent token.
        """
        t0 = time.perf_counter()
        self.total_invocations += 1

        # Check role permission
        has_perm = self.verify_role_permission(requester_role, "VIEW_AGGREGATED_DATA") or requester_role == "authority_auditor"
        if not has_perm:
            exec_time = (time.perf_counter() - t0) * 1000.0
            self.total_execution_time_ms += exec_time
            self._record_threat(requester_id, "UNAUTHORIZED_ACCESS_ATTEMPT", f"Role '{requester_role}' lacks permission for {resource_id}.")
            return False, "Access Denied: Requester role unauthorized.", exec_time

        # Check regulatory consent
        if not has_authority_consent:
            exec_time = (time.perf_counter() - t0) * 1000.0
            self.total_execution_time_ms += exec_time
            self._record_threat(requester_id, "MISSING_REGULATORY_CONSENT", f"Resource {resource_id} requires active consent token.")
            return False, "Access Denied: Missing valid government authority consent.", exec_time

        exec_time = (time.perf_counter() - t0) * 1000.0
        self.total_execution_time_ms += exec_time
        return True, "Access Granted: Authorized by Smart Contract and Regulatory Consent.", exec_time

    def verify_data_integrity(
        self,
        submission_hash: str,
        raw_payload_str: str
    ) -> Tuple[bool, float]:
        """Verifies cryptographic hash consistency of crowdsensed payload."""
        t0 = time.perf_counter()
        computed_hash = sha256_hash(raw_payload_str)
        is_valid = (computed_hash == submission_hash)
        ver_time_ms = (time.perf_counter() - t0) * 1000.0
        return is_valid, ver_time_ms

    def _record_threat(self, entity_id: str, threat_type: str, details: str):
        event = {
            "threat_id": f"THREAT_{len(self.threat_audit_log)+1:05d}",
            "entity_id": entity_id,
            "threat_type": threat_type,
            "details": details,
            "timestamp": time.time()
        }
        self.threat_audit_log.append(event)
