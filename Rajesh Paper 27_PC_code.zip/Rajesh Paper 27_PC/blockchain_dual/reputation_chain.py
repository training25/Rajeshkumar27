"""
Reputation Chain (RC) - Consortium Ethereum Blockchain Layer.
Manages participant identity verification, KYC credential authorization,
and dynamic worker reputation score maintenance via consortium smart contracts.
"""

import time
import json
import hashlib
import numpy as np
from typing import Dict, List, Any, Optional, Tuple


def sha256_hash(data: str) -> str:
    return hashlib.sha256(data.encode('utf-8')).hexdigest()


class RCBlock:
    """Represents a block in the Consortium Reputation Chain."""
    def __init__(
        self,
        index: int,
        prev_hash: str,
        transactions: List[Dict[str, Any]],
        validator_id: str,
        timestamp: Optional[float] = None
    ):
        self.index = index
        self.prev_hash = prev_hash
        self.transactions = transactions
        self.validator_id = validator_id
        self.timestamp = timestamp or time.time()
        self.block_hash = self._compute_hash()

    def _compute_hash(self) -> str:
        tx_str = json.dumps([t["tx_id"] for t in self.transactions])
        raw = f"{self.index}_{self.prev_hash}_{tx_str}_{self.validator_id}_{self.timestamp}"
        return sha256_hash(raw)


class ReputationChain:
    """
    Consortium Reputation Chain (RC).
    Restricted to authorized consortium members (SDN Controller, Municipalities, Telecom Operators).
    """
    def __init__(self, name: str = "Reputation_Chain_Consortium", block_time_sec: float = 1.0, max_tx: int = 128):
        self.name = name
        self.block_time_sec = block_time_sec
        self.max_tx_per_block = max_tx

        self.chain: List[RCBlock] = []
        self.mempool: List[Dict[str, Any]] = []

        # Registered Participant Identity & Reputation Database
        self.participants: Dict[str, Dict[str, Any]] = {}
        # Blinded mapping from pseudo-ID to real identity (accessible only under authority audit)
        self.pseudo_id_map: Dict[str, str] = {}

        self.validators = [f"CONSORTIUM_VAL_{i}" for i in range(5)]
        self.current_val_idx = 0

        self.start_time = time.time()
        self.total_tx_confirmed = 0
        self.tx_latencies_ms: List[float] = []

        self._create_genesis_block()

    def _create_genesis_block(self):
        gen_tx = [{
            "tx_id": sha256_hash("RC_GENESIS_TX"),
            "type": "GENESIS",
            "sender": "AUTHORITY",
            "data": "REPUTATION_CHAIN_INITIALIZED",
            "timestamp": time.time()
        }]
        gen_block = RCBlock(0, "0"*64, gen_tx, self.validators[0])
        self.chain.append(gen_block)

    def register_participant(
        self,
        real_user_id: str,
        public_key: str,
        role: str = "sensing_worker",
        initial_reputation: float = 0.50
    ) -> Tuple[bool, str, str]:
        """
        Registers real user identity on the consortium Reputation Chain.
        Generates an initial pseudonymous session ID for sensing tasks.
        """
        if real_user_id in self.participants:
            return False, "Participant already registered on RC.", ""

        pseudo_id = f"PSEUDO_{sha256_hash(real_user_id + str(time.time()))[:12]}"
        self.pseudo_id_map[pseudo_id] = real_user_id

        record = {
            "real_user_id": real_user_id,
            "public_key": public_key,
            "role": role,
            "reputation_score": float(initial_reputation),
            "total_tasks_completed": 0,
            "penalties_incurred": 0,
            "status": "VERIFIED",
            "registered_at": time.time()
        }
        self.participants[real_user_id] = record

        # Submit transaction to RC mempool
        tx_id = sha256_hash(f"REG_{real_user_id}_{time.time()}")
        tx = {
            "tx_id": tx_id,
            "type": "IDENTITY_REGISTRATION",
            "user_id": real_user_id,
            "pseudo_id": pseudo_id,
            "initial_score": initial_reputation,
            "submitted_at": time.time()
        }
        self.mempool.append(tx)
        return True, "Participant registered successfully.", pseudo_id

    def update_reputation_on_chain(
        self,
        real_user_id: str,
        score_delta: float,
        reason: str
    ) -> Tuple[bool, float, str]:
        """Updates worker reputation score on the consortium ledger."""
        if real_user_id not in self.participants:
            return False, 0.0, "Worker not found on RC."

        worker = self.participants[real_user_id]
        old_score = worker["reputation_score"]
        new_score = float(np.clip(old_score + score_delta, 0.0, 1.0))
        worker["reputation_score"] = new_score
        worker["total_tasks_completed"] += 1
        if score_delta < 0:
            worker["penalties_incurred"] += 1

        tx_id = sha256_hash(f"REP_UPDATE_{real_user_id}_{time.time()}")
        tx = {
            "tx_id": tx_id,
            "type": "REPUTATION_UPDATE",
            "user_id": real_user_id,
            "old_score": round(old_score, 4),
            "new_score": round(new_score, 4),
            "delta": round(score_delta, 4),
            "reason": reason,
            "submitted_at": time.time()
        }
        self.mempool.append(tx)
        return True, new_score, tx_id

    def get_reputation(self, identifier: str) -> Optional[float]:
        """Returns reputation score by real ID or pseudo-ID."""
        if identifier in self.participants:
            return self.participants[identifier]["reputation_score"]
        if identifier in self.pseudo_id_map:
            real_id = self.pseudo_id_map[identifier]
            return self.participants[real_id]["reputation_score"]
        return None

    def mine_pending_block(self) -> Optional[RCBlock]:
        """Consortium PoA block mining."""
        if not self.mempool:
            return None

        batch = self.mempool[:self.max_tx_per_block]
        self.mempool = self.mempool[self.max_tx_per_block:]

        validator = self.validators[self.current_val_idx]
        self.current_val_idx = (self.current_val_idx + 1) % len(self.validators)

        now = time.time()
        new_block = RCBlock(
            index=len(self.chain),
            prev_hash=self.chain[-1].block_hash,
            transactions=batch,
            validator_id=validator,
            timestamp=now
        )
        self.chain.append(new_block)

        for tx in batch:
            latency = (now - tx["submitted_at"]) * 1000.0
            self.tx_latencies_ms.append(latency)
        self.total_tx_confirmed += len(batch)

        return new_block

    def get_throughput_tps(self) -> float:
        elapsed = time.time() - self.start_time
        return self.total_tx_confirmed / max(0.1, elapsed)
