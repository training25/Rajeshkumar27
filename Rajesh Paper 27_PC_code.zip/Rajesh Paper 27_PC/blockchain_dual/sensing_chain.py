"""
Sensing Chain (SC) - Public Blockchain Layer.
Records crowdsensing task announcements, worker pseudo-bids, and f-DP perturbed
sensing data submissions without exposing persistent physical worker identities.
"""

import time
import json
import hashlib
from typing import Dict, List, Any, Optional, Tuple


def sha256_hash(data: str) -> str:
    """Computes SHA-256 hex string."""
    return hashlib.sha256(data.encode('utf-8')).hexdigest()


class SCMerkleTree:
    """Binary Merkle Tree for Sensing Chain block transactions."""
    def __init__(self, leaves: List[str]):
        self.leaves = leaves if leaves else [sha256_hash("EMPTY_SC_LEAF")]
        self.levels: List[List[str]] = []
        self._build_tree()

    def _build_tree(self):
        current = [sha256_hash(leaf) if len(leaf) != 64 else leaf for leaf in self.leaves]
        self.levels.append(current)

        while len(current) > 1:
            next_level = []
            for i in range(0, len(current), 2):
                left = current[i]
                right = current[i+1] if (i+1 < len(current)) else left
                combined = sha256_hash(left + right)
                next_level.append(combined)
            current = next_level
            self.levels.append(current)

    @property
    def root(self) -> str:
        return self.levels[-1][0]

    def get_proof(self, index: int) -> List[Tuple[str, str]]:
        proof = []
        for level in self.levels[:-1]:
            is_right = (index % 2 == 1)
            sibling_idx = (index - 1) if is_right else (index + 1)
            sibling = level[sibling_idx] if sibling_idx < len(level) else level[index]
            proof.append(("left" if is_right else "right", sibling))
            index = index // 2
        return proof

    @staticmethod
    def verify_proof(leaf: str, proof: List[Tuple[str, str]], expected_root: str) -> bool:
        current = sha256_hash(leaf) if len(leaf) != 64 else leaf
        for direction, sibling in proof:
            if direction == "left":
                current = sha256_hash(sibling + current)
            else:
                current = sha256_hash(current + sibling)
        return current == expected_root


class SCBlock:
    """Represents a block in the Sensing Chain (SC)."""
    def __init__(
        self,
        index: int,
        prev_hash: str,
        transactions: List[Dict[str, Any]],
        miner_id: str,
        timestamp: Optional[float] = None
    ):
        self.index = index
        self.prev_hash = prev_hash
        self.transactions = transactions
        self.miner_id = miner_id
        self.timestamp = timestamp or time.time()

        tx_ids = [tx["tx_id"] for tx in self.transactions]
        self.merkle_tree = SCMerkleTree(tx_ids)
        self.merkle_root = self.merkle_tree.root
        self.block_hash = self._compute_hash()

    def _compute_hash(self) -> str:
        raw = f"{self.index}_{self.prev_hash}_{self.merkle_root}_{self.miner_id}_{self.timestamp}"
        return sha256_hash(raw)


class SensingChain:
    """
    Public Sensing Chain (SC) Engine.
    Handles crowdsourcing task lifecycle and pseudonymous data anchoring.
    """
    def __init__(self, name: str = "Sensing_Chain_Public", block_time_sec: float = 0.5, max_tx: int = 64):
        self.name = name
        self.block_time_sec = block_time_sec
        self.max_tx_per_block = max_tx

        self.chain: List[SCBlock] = []
        self.mempool: List[Dict[str, Any]] = []
        self.tasks: Dict[str, Dict[str, Any]] = {}

        self.start_time = time.time()
        self.total_tx_confirmed = 0
        self.tx_latencies_ms: List[float] = []

        self._create_genesis_block()

    def _create_genesis_block(self):
        genesis_tx = [{
            "tx_id": sha256_hash("SC_GENESIS_TX"),
            "type": "GENESIS",
            "sender": "SYSTEM",
            "data": "SENSING_CHAIN_GENESIS",
            "timestamp": time.time()
        }]
        gen_block = SCBlock(0, "0"*64, genesis_tx, "GENESIS_NODE")
        self.chain.append(gen_block)

    def publish_task(
        self,
        publisher_id: str,
        task_id: str,
        task_type: str,
        min_reputation: float,
        reward_tokens: float,
        required_samples: int = 5
    ) -> str:
        """Publishes a crowdsensing task on SC."""
        sub_time = time.time()
        tx_id = sha256_hash(f"TASK_PUB_{publisher_id}_{task_id}_{sub_time}")

        task_data = {
            "task_id": task_id,
            "publisher_id": publisher_id,
            "task_type": task_type,
            "min_reputation": min_reputation,
            "reward_tokens": reward_tokens,
            "required_samples": required_samples,
            "submissions": [],
            "status": "OPEN",
            "created_at": sub_time
        }
        self.tasks[task_id] = task_data

        tx = {
            "tx_id": tx_id,
            "type": "TASK_PUBLISH",
            "sender": publisher_id,
            "task_id": task_id,
            "payload": task_data,
            "submitted_at": sub_time
        }
        self.mempool.append(tx)
        return tx_id

    def submit_sensing_data(
        self,
        task_id: str,
        worker_pseudo_id: str,
        perturbed_data_hash: str,
        data_payload: Dict[str, Any]
    ) -> str:
        """
        Submits perturbed sensing data using a pseudonymous worker ID.
        Identity de-linking ensures public observers cannot link sensing to real worker.
        """
        sub_time = time.time()
        tx_id = sha256_hash(f"DATA_SUB_{task_id}_{worker_pseudo_id}_{sub_time}")

        submission = {
            "tx_id": tx_id,
            "type": "SENSING_DATA_SUBMISSION",
            "task_id": task_id,
            "worker_pseudo_id": worker_pseudo_id,
            "data_hash": perturbed_data_hash,
            "payload": data_payload,
            "submitted_at": sub_time
        }

        if task_id in self.tasks:
            self.tasks[task_id]["submissions"].append(submission)
            if len(self.tasks[task_id]["submissions"]) >= self.tasks[task_id]["required_samples"]:
                self.tasks[task_id]["status"] = "COLLECTED"

        self.mempool.append(submission)
        return tx_id

    def mine_pending_block(self) -> Optional[SCBlock]:
        """Mines pending transactions into a new SC block."""
        if not self.mempool:
            return None

        batch = self.mempool[:self.max_tx_per_block]
        self.mempool = self.mempool[self.max_tx_per_block:]

        now = time.time()
        new_block = SCBlock(
            index=len(self.chain),
            prev_hash=self.chain[-1].block_hash,
            transactions=batch,
            miner_id=f"SC_MINER_{len(self.chain)%3}",
            timestamp=now
        )
        self.chain.append(new_block)

        for tx in batch:
            latency = (now - tx["submitted_at"]) * 1000.0
            self.tx_latencies_ms.append(latency)
        self.total_tx_confirmed += len(batch)

        return new_block

    def get_throughput_tps(self) -> float:
        """Calculates throughput (TPS)."""
        elapsed = time.time() - self.start_time
        return self.total_tx_confirmed / max(0.1, elapsed)

    def get_proof(self, tx_id: str) -> Optional[Tuple[str, List[Tuple[str, str]], int]]:
        """Retrieves Merkle proof for cross-chain relay."""
        for block in reversed(self.chain):
            for idx, tx in enumerate(block.transactions):
                if tx["tx_id"] == tx_id:
                    proof = block.merkle_tree.get_proof(idx)
                    return block.merkle_root, proof, block.index
        return None
