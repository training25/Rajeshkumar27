"""
Dynamic Reputation Management Module.
Evaluates crowdsourcing contribution quality, multi-worker spatial consistency,
timeliness, detects malicious data poisoning, and calculates reputation deltas.
"""

import time
import math
import numpy as np
from typing import Dict, List, Any, Tuple, Optional
from config.system_config import DynamicReputationConfig


class DynamicReputationEngine:
    """
    Evaluates worker submissions and maintains dynamic reputation scores.
    Features:
    - Multi-worker spatial-temporal consensus comparison
    - SNR / data fidelity evaluation
    - Asymmetric penalty for poisoned/fabricated data
    - Historical exponential time-decay
    """
    def __init__(self, config: Optional[DynamicReputationConfig] = None):
        self.config = config or DynamicReputationConfig()
        self.w_cons = self.config.consistency_weight
        self.w_qual = self.config.quality_weight
        self.w_time = self.config.timeliness_weight
        self.decay = self.config.decay_factor
        self.penalty_mult = self.config.malicious_penalty_multiplier

    def evaluate_task_contributions(
        self,
        submissions: List[Dict[str, Any]],
        ground_truth_reference: Optional[np.ndarray] = None,
        deadline_sec: float = 5.0
    ) -> List[Dict[str, Any]]:
        """
        Evaluates a batch of submissions for a completed crowdsourcing task.
        Computes consensus vector, individual quality scores, and reputation adjustments.
        """
        if not submissions:
            return []

        # Extract numerical sensing vectors
        vectors = []
        valid_indices = []
        for i, sub in enumerate(submissions):
            payload = sub.get("payload", {})
            vec = payload.get("perturbed_vector", None)
            if vec is not None:
                vectors.append(np.array(vec, dtype=np.float32))
                valid_indices.append(i)

        if not vectors:
            return []

        data_matrix = np.array(vectors) # Shape: (M, D)
        # Robust multi-worker consensus mean (trimmed mean or median)
        consensus_median = np.median(data_matrix, axis=0)

        evaluation_results = []

        for idx, sub_idx in enumerate(valid_indices):
            sub = submissions[sub_idx]
            worker_id = sub.get("worker_pseudo_id", f"WORKER_{idx}")
            vec = vectors[idx]
            tx_time = sub.get("submitted_at", time.time())

            # 1. Consistency Score: Inversely proportional to Euclidean distance from median
            dist_to_consensus = float(np.linalg.norm(vec - consensus_median))
            consistency_score = float(np.exp(-dist_to_consensus / 10.0))

            # 2. Quality Score: SNR or bound adherence
            is_physically_plausible = bool(np.all(vec > -50.0) and np.all(vec < 5000.0))
            if ground_truth_reference is not None:
                err_gt = float(np.mean((vec - ground_truth_reference) ** 2))
                quality_score = float(np.exp(-err_gt / 50.0))
            else:
                quality_score = 1.0 if is_physically_plausible else 0.1

            # 3. Timeliness Score
            elapsed = max(0.1, time.time() - tx_time)
            timeliness_score = float(np.clip(1.0 - (elapsed / deadline_sec), 0.2, 1.0))

            # Malicious poisoning check
            # A submission deviates drastically (> 3 sigma) from consensus or has bogus payload
            is_poisoned = (dist_to_consensus > 25.0) or (not is_physically_plausible)

            if is_poisoned:
                raw_delta = - (0.15 * self.penalty_mult)
                status = "MALICIOUS_POISONING_DETECTED"
            else:
                # Combined positive reinforcement
                composite_score = (
                    self.w_cons * consistency_score +
                    self.w_qual * quality_score +
                    self.w_time * timeliness_score
                )
                raw_delta = float(0.04 * (composite_score - 0.5))
                status = "VERIFIED_HIGH_QUALITY" if composite_score > 0.75 else "ACCEPTABLE"

            eval_record = {
                "worker_pseudo_id": worker_id,
                "consistency_score": round(consistency_score, 4),
                "quality_score": round(quality_score, 4),
                "timeliness_score": round(timeliness_score, 4),
                "is_poisoned": is_poisoned,
                "reputation_delta": round(raw_delta, 4),
                "status": status
            }
            evaluation_results.append(eval_record)

        return evaluation_results
