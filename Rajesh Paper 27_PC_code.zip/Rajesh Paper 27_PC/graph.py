import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.font_manager import FontProperties

# Load data
df = pd.read_csv("C:/work/Rajesh Paper 27_PC/comparative_benchmarks.csv")

# Font settings
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 18
plt.rcParams['font.weight'] = 'bold'
plt.rcParams['axes.labelweight'] = 'bold'

methods = ['Proposed\n(Dual-BC + f-DP + DFRL)', 'APB-FLDPA [8]', 'TAWB-SFL [14]', 'Single Blockchain']
cols = ['Proposed (Dual-BC + f-DP + DFRL)', 'APB-FLDPA [8]', 'TAWB-SFL [14]', 'Single Blockchain']
colors = ['#2ecc71', '#3498db', '#e67e22', '#e74c3c']
x = np.arange(len(methods))

# Get all metrics
metrics = df['Metric'].tolist()
units = df['Unit'].tolist()

for i, (metric, unit) in enumerate(zip(metrics, units)):
    fig, ax = plt.subplots(figsize=(10, 6))
    
    values = df[df['Metric'] == metric][cols].values.astype(float)[0]
    
    bars = ax.bar(x, values, color=colors, edgecolor='black', linewidth=1.5, width=0.6)
    
    # Add value labels on bars
    for bar, val in zip(bars, values):
        height = bar.get_height()
        ax.annotate(f'{val:.2f}',
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 5),
                    textcoords="offset points",
                    ha='center', va='bottom',
                    fontsize=14, fontweight='bold')
    
    ax.set_xticks(x)
    ax.set_xticklabels(methods, fontsize=15)
    ax.set_ylabel(f'{metric} ({unit})', fontsize=18, fontweight='bold')
    
    # Legend
    ax.legend(bars, methods, 
              loc='lower center',
              bbox_to_anchor=(0.5, 1.02),
              ncol=2,
              fontsize=13,
              frameon=True,
              edgecolor='black')
    
    # Border
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(1.5)
        spine.set_edgecolor('black')
    
    ax.grid(axis='y', linestyle='--', alpha=0.6)
    ax.set_axisbelow(True)
    
    # Adjust y-limit to give space for labels
    ymax = max(values) * 1.18
    ax.set_ylim(0, ymax)
    
    plt.tight_layout()
    
    # Clean filename
    filename = f"graph_{metric.lower().replace(' ', '_').replace('-', '_')}.png"
    plt.savefig(filename, dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()
    print(f"Saved: {filename}")

print("\nAll separate graphs generated successfully!")