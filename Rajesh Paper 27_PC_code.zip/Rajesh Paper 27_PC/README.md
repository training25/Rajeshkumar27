# Privacy-Preserved Dual-Blockchain Reputation Management with Differential Privacy for Secure Crowdsourcing Data Sharing in SDNs

Official Python implementation of the **Privacy-Preserved Dual-Blockchain Framework with Local-Node $f$-Differential Privacy ($f$-DP) and Decentralized Federated Reinforcement Learning (DFRL) for Crowdsourcing Data Sharing in Software-Defined Networks (SDNs)**.

---

## 📌 Architectural Overview & Innovations

```
                       [ Crowdsourcing IoT Workers & Mobile Devices ]
                                             │
                 ┌───────────────────────────┴───────────────────────────┐
                 │                                                       │
   [ Local-Node f-Differential Privacy ]                 [ Participant Identity De-linking ]
   - Gaussian DP Trade-Off f_mu(alpha)                   - Real KYC Identity Registered on RC
   - L2 Sensitivity Norm Bounding                        - Anonymous Pseudo-IDs Used on SC
   - Calibrated Gaussian Perturbation                    - Linking Attack Mitigation
                 │                                                       │
                 └───────────────────────────┬───────────────────────────┘
                                             │
              [ Software-Defined Network (SDN) Virtual Forwarding Overlay ]
              - OpenFlow Flow Table Scheduling & Traffic Dynamics
              - Priority Queuing for High-Reputation Workers
              - Decentralized Federated Reinforcement Learning (DFRL)
                                             │
      ┌──────────────────────────────────────┴──────────────────────────────────────┐
      │                                                                             │
[ Sensing Chain (SC - Public Layer) ]                    [ Reputation Chain (RC - Consortium Layer) ]
- Task Announcements & Requirements                      - Participant Identity Registration & KYC
- Worker Pseudonymous Bids                               - Smart Contract Dynamic Reputation State
- Perturbed Sensing Data Submissions                     - Consortium PoA / Raft Consensus
- Binary Merkle Tree Integrity Proofs                    - Cross-Chain Bridge Notarization
      │                                                                             │
      └──────────────────────────────────────┬──────────────────────────────────────┘
                                             │
              [ Government / Regulatory Authority Governance & Consent ]
              ├── Automated Cryptographic Data-Access Consent Tokens
              ├── Compliance Verification (GDPR, HIPAA, NIST SP 800-53)
              └── Authorized De-anonymization under Judicial Warrants
```

---

## 🔬 Key Mathematical Formulations

### 1. Local-Node $f$-Differential Privacy ($f$-DP)
Formulated under Gaussian Differential Privacy ($\mu$-GDP) via hypothesis testing trade-off function $f_\mu(\alpha)$:
$$f_\mu(\alpha) = \Phi\left( \Phi^{-1}(1 - \alpha) - \mu \right)$$
where $\Phi$ is the standard normal cumulative distribution function (CDF).
Conversion to standard $(\epsilon, \delta)$-DP:
$$\delta(\epsilon) = \Phi\left(-\frac{\epsilon}{\mu} + \frac{\mu}{2}\right) - e^{\epsilon} \Phi\left(-\frac{\epsilon}{\mu} - \frac{\mu}{2}\right)$$
Local sensing vector perturbation:
$$x_{\text{clipped}} = \frac{x}{\max\left(1, \frac{\|x\|_2}{C}\right)}, \quad x_{\text{priv}} = x_{\text{clipped}} + \mathcal{N}\left(0, \sigma^2 I\right), \quad \sigma = \frac{\Delta_2}{\mu}$$

### 2. Dynamic Reputation Scoring
Updates worker reputation $R_{t+1}$ based on spatial consistency $S_{\text{cons}}$, quality $S_{\text{qual}}$, timeliness $S_{\text{time}}$, and malicious data poisoning penalty $P_{\text{mal}}$:
$$S_{\text{cons}} = \exp\left(-\frac{\|x_i - \text{median}(X)\|_2}{\theta}\right)$$
$$\Delta R = w_{\text{cons}} S_{\text{cons}} + w_{\text{qual}} S_{\text{qual}} + w_{\text{time}} S_{\text{time}} - P_{\text{mal}}$$
$$R_{t+1} = \text{clip}\left( \gamma R_t + (1 - \gamma) \Delta R, \; 0.0, \; 1.0 \right)$$

### 3. Decentralized Federated Reinforcement Learning (DFRL)
Decentralized Q-learning updates at distributed SDN edge switches:
$$Q_i(s, a) \leftarrow Q_i(s, a) + \alpha \left[ r + \gamma \max_{a'} Q_i(s', a') - Q_i(s, a) \right]$$
Federated reputation-weighted aggregation on central SDN controller:
$$w_i = \frac{N_i \cdot \text{Rep}_i}{\sum_j N_j \cdot \text{Rep}_j}, \quad Q_{\text{global}}(s, a) = \sum_{i=1}^M w_i Q_i(s, a)$$

---

## 📁 Repository Structure

```
C:\work\Rajesh Paper 27_PC\
├── config/
│   └── system_config.py           # Central configurations (dual-chain, f-DP, SDN, DFRL, authority)
├── privacy_fdp/
│   └── f_differential_privacy.py  # Local-Node f-Differential Privacy (mu-GDP, trade-off curve, SNR)
├── blockchain_dual/
│   ├── sensing_chain.py           # Sensing Chain (SC - Public Layer for tasks & pseudonymous data)
│   ├── reputation_chain.py        # Reputation Chain (RC - Consortium Layer for identity & reputation)
│   ├── smart_contracts.py         # Smart contracts (Bidding, Access Control, Integrity Verification)
│   └── cross_chain_bridge.py      # Cross-Chain Bridge protocol connecting SC and RC
├── reputation_engine/
│   └── dynamic_reputation.py      # Dynamic reputation evaluation (consistency, SNR, poisoning check)
├── sdn_network/
│   └── sdn_crowdsourcing_env.py   # SDN wireless overlay (virtual switches, latency, loss, queues)
├── learning_dfrl/
│   └── dfrl_agent.py              # Decentralized Federated Reinforcement Learning for task routing
├── authority_consent/
│   └── regulatory_consent.py      # Government authority automated consent tokens & compliance audit
├── data/
│   └── crowdsourcing_dataset.py   # Urban IoT crowdsensing generator & cyberattack stream
├── evaluation/
│   ├── metrics.py                 # Complete 15-metric performance evaluation engine
│   └── visualizer.py              # Publication-ready comparative plotting engine
├── main.py                        # Master end-to-end benchmark pipeline
├── test_system.py                 # Comprehensive 10-module unit & system test suite
├── requirements.txt               # Dependencies
└── README.md                      # Academic documentation
```

---

## 📊 Comprehensive 15 Research Metrics

| Metric | Target Subsystem | Description |
| :--- | :--- | :--- |
| **1. Accuracy** | Smart Contract + Reputation | Overall attack and poisoning classification rate (%) |
| **2. Precision** | Smart Contract + Reputation | Positive predictive value for intrusion detection (%) |
| **3. Recall** | Smart Contract + Reputation | True positive attack detection sensitivity (%) |
| **4. F1-Score** | Smart Contract + Reputation | Harmonic mean of precision and recall (%) |
| **5. AUC-ROC** | Anomaly Evaluator | Area under the Receiver Operating Characteristic curve |
| **6. Attack Detection Latency** | Cross-Chain + Smart Contract | Duration to identify and isolate adversarial attacks (ms) |
| **7. Unauthorized Access Detection Rate** | Regulatory Consent Manager | Percentage of blocked unconsented query attempts (%) |
| **8. Data Integrity Verification Time** | SC Merkle Proof + SHA-256 | Cryptographic integrity verification duration (ms) |
| **9. Blockchain Transaction Throughput** | Dual Blockchain (SC + RC) | Combined sustained transaction throughput (TPS) |
| **10. Smart Contract Execution Time** | EVM Runtime Engine | Average invocation latency for on-chain contract logic (ms) |
| **11. End-to-End Data Sharing Delay** | SDN Overlay + Cross-Chain | Complete data transmission and anchoring delay (ms) |
| **12. Network Bandwidth Utilization** | SDN Controller Overlay | Overlay link capacity utilization efficiency (%) |
| **13. Packet Loss Rate** | SDN Flow Forwarding | Packet drop percentage under dynamic wireless links (%) |
| **14. Computational Overhead** | f-DP + DFRL + Crypto | CPU execution duration (ms) and memory footprint (KB) |
| **15. Scalability** | Dual-Chain + SDN | Latency and throughput stability across 10 to 200 workers |

---

## 🚀 Execution Instructions

### 1. Install Dependencies
```bash
cd "C:\work\Rajesh Paper 27_PC"
pip install -r requirements.txt
```

### 2. Run Comprehensive Unit & System Tests
Verifies all 10 architectural modules, $f$-DP trade-off functions, dual-chain blocks, and cross-chain relay:
```bash
python test_system.py
```

### 3. Run Master Simulation & Benchmark Pipeline
Executes the full proposed workflow, outputs the complete 15-metric performance summary table, and generates publication figures:
```bash
python main.py
```

Output figures are automatically saved to `C:\work\Rajesh Paper 27_PC\results\`:
- `fig1_detection_comparison.png` (Comparison with APB-FLDPA [8], TAWB-SFL [14], Single Blockchain)
- `fig2_fdp_privacy_utility.png` (Local $f$-DP trade-off: SNR vs. MSE distortion across $\epsilon$)
- `fig3_blockchain_throughput.png` (Dual-blockchain throughput scalability vs Single Blockchain)
- `fig4_scalability_delay.png` (Transmission latency scaling across 10 to 200 workers)
- `crowdsourcing_metrics.json` (Structured JSON record of all experimental results)
