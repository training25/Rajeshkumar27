"""
Decentralized Federated Reinforcement Learning (DFRL) Module.
Enables distributed SDN edge controllers and crowdsourcing nodes to cooperatively
optimize task forwarding, path selection, and cross-chain synchronization without sharing raw data.
"""

import numpy as np
from typing import Dict, List, Tuple, Any, Optional
from config.system_config import DFRLConfig


class LocalDFRLClient:
    """
    Local edge switch / crowdsourcing node RL agent.
    Learns state-action values for task allocation and path routing.
    """
    def __init__(
        self,
        client_id: str,
        num_states: int = 16,
        num_actions: int = 4,
        config: Optional[DFRLConfig] = None,
        seed: int = 42
    ):
        self.client_id = client_id
        self.num_states = num_states
        self.num_actions = num_actions
        self.config = config or DFRLConfig()
        self.rng = np.random.RandomState(seed)

        self.q_table = np.zeros((num_states, num_actions), dtype=np.float32)
        self.lr = self.config.learning_rate
        self.gamma = self.config.discount_factor
        self.epsilon = self.config.exploration_epsilon

        self.experiences_count = 0
        self.total_rewards: List[float] = []
        self.reputation_weight: float = 1.0

    def select_action(self, state: int) -> int:
        """Epsilon-greedy action selection."""
        if self.rng.rand() < self.epsilon:
            return int(self.rng.choice(self.num_actions))
        q_row = self.q_table[state]
        max_val = np.max(q_row)
        best_actions = np.where(q_row == max_val)[0]
        return int(self.rng.choice(best_actions))

    def update(self, state: int, action: int, reward: float, next_state: int):
        """Standard Q-learning update."""
        current_q = self.q_table[state, action]
        max_next_q = np.max(self.q_table[next_state])
        td_target = reward + self.gamma * max_next_q
        self.q_table[state, action] += self.lr * (td_target - current_q)

        self.experiences_count += 1
        self.total_rewards.append(reward)
        self.epsilon = max(self.config.min_epsilon, self.epsilon * self.config.epsilon_decay)

    def get_avg_reward(self) -> float:
        if not self.total_rewards:
            return 0.0
        return float(np.mean(self.total_rewards[-40:]))


class GlobalDFRLServer:
    """
    Central SDN Controller Federated Aggregator.
    Coordinates federated learning rounds with reputation-weighted aggregation.
    """
    def __init__(
        self,
        num_states: int = 16,
        num_actions: int = 4,
        config: Optional[DFRLConfig] = None
    ):
        self.num_states = num_states
        self.num_actions = num_actions
        self.config = config or DFRLConfig()

        self.global_q_table = np.zeros((num_states, num_actions), dtype=np.float32)
        self.clients: Dict[str, LocalDFRLClient] = {}
        self.federated_round = 0
        self.round_history: List[Dict[str, Any]] = []

    def register_client(self, client: LocalDFRLClient):
        self.clients[client.client_id] = client

    def aggregate_federated_round(self) -> Tuple[np.ndarray, Dict[str, float]]:
        """
        Federated aggregation weighted by local experience count and node reputation:
        Weight w_i = (N_i * Rep_i) / sum(N_j * Rep_j)
        Q_global = sum(w_i * Q_i)
        """
        self.federated_round += 1
        raw_weights = {}

        for cid, client in self.clients.items():
            n = max(1, client.experiences_count)
            rep = max(0.2, client.reputation_weight)
            raw_weights[cid] = n * rep

        total_weight = sum(raw_weights.values()) + 1e-8
        normalized_weights = {cid: (w / total_weight) for cid, w in raw_weights.items()}

        new_global_q = np.zeros_like(self.global_q_table)
        for cid, client in self.clients.items():
            w = normalized_weights[cid]
            new_global_q += w * client.q_table

        self.global_q_table = new_global_q

        # Broadcast updated policy to edge clients
        for client in self.clients.values():
            client.q_table = np.copy(self.global_q_table)

        round_record = {
            "round": self.federated_round,
            "weights": normalized_weights,
            "mean_q_val": round(float(np.mean(self.global_q_table)), 4)
        }
        self.round_history.append(round_record)
        return self.global_q_table, normalized_weights

    @staticmethod
    def map_environment_state(
        worker_reputation: float,
        best_path_lat_ms: float,
        path_loss_rate: float,
        network_congestion: float
    ) -> int:
        """Discretizes continuous network and worker state into [0..15]."""
        rep_bin = 0 if worker_reputation < 0.60 else 1
        lat_bin = 0 if best_path_lat_ms < 20.0 else 1
        loss_bin = 0 if path_loss_rate < 0.015 else 1
        cong_bin = 0 if network_congestion < 0.70 else 1

        state_idx = (rep_bin * 8 + lat_bin * 4 + loss_bin * 2 + cong_bin) % 16
        return int(state_idx)

    @staticmethod
    def calculate_reward(
        total_delay_ms: float,
        dropped: bool,
        worker_reputation: float,
        task_reward_tokens: float
    ) -> float:
        """Reinforcement learning reward balancing latency, delivery success, and tokens."""
        if dropped:
            return -45.0

        lat_penalty = - (total_delay_ms / 15.0)
        rep_bonus = worker_reputation * 10.0
        token_bonus = task_reward_tokens * 2.0
        return float(round(lat_penalty + rep_bonus + token_bonus, 2))
