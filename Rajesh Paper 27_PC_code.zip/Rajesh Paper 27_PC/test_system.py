"""
Unit & System Verification Test Suite for Dual-Blockchain Crowdsourcing Framework.
Validates all 10 core architectural modules:
1. Local-Node f-Differential Privacy (f-DP)
2. Sensing Chain (SC - Public Layer)
3. Reputation Chain (RC - Consortium Layer)
4. Cross-Chain Communication Bridge
5. Dual Smart Contracts & Access Control
6. Dynamic Reputation Management Engine
7. SDN Crowdsourcing Network Overlay
8. Decentralized Federated Reinforcement Learning (DFRL)
9. Regulatory Authority Automated Consent Manager
10. Comprehensive 15-Metric Evaluator
"""

import os
import sys
import unittest
import numpy as np

# Ensure root directory is in python search path
CURR_DIR = os.path.dirname(os.path.abspath(__file__))
if CURR_DIR not in sys.path:
    sys.path.insert(0, CURR_DIR)

from config.system_config import get_default_config
from privacy_fdp.f_differential_privacy import LocalNodeFDifferentialPrivacy
from blockchain_dual.sensing_chain import SensingChain, sha256_hash, SCMerkleTree
from blockchain_dual.reputation_chain import ReputationChain
from blockchain_dual.smart_contracts import DualSmartContractEngine
from blockchain_dual.cross_chain_bridge import DualBlockchainCrossBridge
from reputation_engine.dynamic_reputation import DynamicReputationEngine
from sdn_network.sdn_crowdsourcing_env import SDNCrowdsourcingNetwork
from learning_dfrl.dfrl_agent import LocalDFRLClient, GlobalDFRLServer
from authority_consent.regulatory_consent import RegulatoryConsentManager
from evaluation.metrics import DualBlockchainMetricsEvaluator


class TestDualBlockchainCrowdsourcing(unittest.TestCase):
    def setUp(self):
        self.cfg = get_default_config()

    def test_01_fdp_mechanism(self):
        fdp = LocalNodeFDifferentialPrivacy(config=self.cfg.fdp, seed=42)
        raw_vec = np.array([25.0, 50.0, 75.0, 100.0], dtype=np.float32)

        pert_vec, metrics = fdp.perturb_sensing_data(raw_vec)
        self.assertEqual(pert_vec.shape, raw_vec.shape)
        self.assertIn("snr_db", metrics)
        self.assertIn("mu_gdp", metrics)

        # Trade-off function test
        trade_off_val = fdp.trade_off_function(0.05)
        self.assertGreaterEqual(trade_off_val, 0.0)
        self.assertLessEqual(trade_off_val, 1.0)
        print(" [✓] Local-node f-Differential Privacy verified.")

    def test_02_sensing_chain(self):
        sc = SensingChain("Test_SC")
        tx_pub = sc.publish_task("PUB_1", "TASK_001", "AIR_QUALITY", min_reputation=0.4, reward_tokens=10.0)
        self.assertIsNotNone(tx_pub)

        tx_sub = sc.submit_sensing_data("TASK_001", "PSEUDO_W_1", sha256_hash("DATA"), {"val": [1, 2]})
        self.assertIsNotNone(tx_sub)

        block = sc.mine_pending_block()
        self.assertIsNotNone(block)
        self.assertEqual(block.index, 1)

        proof_data = sc.get_proof(tx_sub)
        self.assertIsNotNone(proof_data)
        root, proof, b_idx = proof_data
        self.assertTrue(SCMerkleTree.verify_proof(tx_sub, proof, root))
        print(" [✓] Sensing Chain (SC) & Merkle Verification verified.")

    def test_03_reputation_chain(self):
        rc = ReputationChain("Test_RC")
        ok, msg, pseudo_id = rc.register_participant("ALICE", sha256_hash("PUB_ALICE"), initial_reputation=0.5)
        self.assertTrue(ok)
        self.assertTrue(pseudo_id.startswith("PSEUDO_"))

        # Update reputation
        ok_up, new_score, tx_up = rc.update_reputation_on_chain("ALICE", score_delta=0.08, reason="High Quality")
        self.assertTrue(ok_up)
        self.assertAlmostEqual(new_score, 0.58, places=2)

        # Lookup by pseudo-ID
        score_by_pseudo = rc.get_reputation(pseudo_id)
        self.assertAlmostEqual(score_by_pseudo, 0.58, places=2)
        print(" [✓] Reputation Chain (RC) & Identity De-linking verified.")

    def test_04_cross_chain_bridge(self):
        sc = SensingChain("Bridge_SC")
        rc = ReputationChain("Bridge_RC")
        contracts = DualSmartContractEngine()
        bridge = DualBlockchainCrossBridge(sc, rc, contracts)

        # Register worker
        _, _, pseudo_id = rc.register_participant("BOB", sha256_hash("PUB_BOB"), initial_reputation=0.7)

        # Cross-chain threshold query
        is_ok, score, delay = bridge.verify_reputation_threshold_cross_chain(pseudo_id, required_threshold=0.5)
        self.assertTrue(is_ok)
        self.assertAlmostEqual(score, 0.7, places=2)

        # Cross-chain update commit
        ok_sync, updated_score, _ = bridge.sync_reputation_update_cross_chain(pseudo_id, 0.05, "Task Completed", "TASK_001")
        self.assertTrue(ok_sync)
        self.assertAlmostEqual(updated_score, 0.75, places=2)
        print(" [✓] Cross-Chain Communication Bridge verified.")

    def test_05_smart_contracts(self):
        engine = DualSmartContractEngine()

        # Bid verification
        ok_bid, _, _ = engine.validate_task_bid("PSEUDO_1", "TASK_1", worker_reputation=0.65, task_min_reputation=0.50)
        self.assertTrue(ok_bid)

        # Ineligible bid
        bad_bid, _, _ = engine.validate_task_bid("PSEUDO_2", "TASK_1", worker_reputation=0.30, task_min_reputation=0.50)
        self.assertFalse(bad_bid)

        # Access control
        ok_access, _, _ = engine.evaluate_access_authorization("PUB_1", "task_publisher", "DATASET_1", has_authority_consent=True)
        self.assertTrue(ok_access)

        bad_access, _, _ = engine.evaluate_access_authorization("ROGUE", "unknown_role", "DATASET_1", has_authority_consent=False)
        self.assertFalse(bad_access)
        print(" [✓] Dual Smart Contracts Engine verified.")

    def test_06_dynamic_reputation(self):
        rep_engine = DynamicReputationEngine(self.cfg.reputation)
        subs = [
            {"worker_pseudo_id": "W1", "payload": {"perturbed_vector": [28.0, 54.0, 31.0]}},
            {"worker_pseudo_id": "W2", "payload": {"perturbed_vector": [29.0, 56.0, 33.0]}},
            {"worker_pseudo_id": "W_MALICIOUS", "payload": {"perturbed_vector": [450.0, 890.0, 920.0]}} # Poisoned
        ]

        eval_res = rep_engine.evaluate_task_contributions(subs, ground_truth_reference=np.array([28.5, 55.0, 32.0]))
        self.assertEqual(len(eval_res), 3)

        malicious_res = [r for r in eval_res if r["worker_pseudo_id"] == "W_MALICIOUS"][0]
        self.assertTrue(malicious_res["is_poisoned"])
        self.assertLess(malicious_res["reputation_delta"], 0.0)
        print(" [✓] Dynamic Reputation Scoring & Poisoning Detection verified.")

    def test_07_sdn_overlay(self):
        sdn = SDNCrowdsourcingNetwork(self.cfg.sdn, seed=42)
        sdn.step_environment()
        res = sdn.forward_crowdsourced_packet(packet_size_bytes=512, path_id=0, worker_reputation=0.8, is_authenticated=True)
        self.assertIn("total_delay_ms", res)
        self.assertIn("bandwidth_utilization_pct", res)
        self.assertFalse(res["dropped"])
        print(" [✓] SDN Crowdsourcing Overlay Network verified.")

    def test_08_dfrl_agent(self):
        server = GlobalDFRLServer(16, 4)
        c1 = LocalDFRLClient("EDGE_1", 16, 4, seed=1)
        c2 = LocalDFRLClient("EDGE_2", 16, 4, seed=2)
        server.register_client(c1)
        server.register_client(c2)

        a = c1.select_action(0)
        c1.update(state=0, action=a, reward=5.0, next_state=1)
        self.assertGreater(c1.experiences_count, 0)

        g_q, weights = server.aggregate_federated_round()
        self.assertIn("EDGE_1", weights)
        self.assertIn("EDGE_2", weights)
        self.assertAlmostEqual(sum(weights.values()), 1.0, places=4)
        print(" [✓] Decentralized Federated Reinforcement Learning (DFRL) verified.")

    def test_09_regulatory_consent(self):
        auth = RegulatoryConsentManager(self.cfg.authority)
        ok_issue, msg, token = auth.issue_data_access_consent("RESEARCHER_1", "task_publisher", "DATASET_42", "URBAN_HEAT", worker_reputation=0.8)
        self.assertTrue(ok_issue)
        self.assertIsNotNone(token)

        is_valid = auth.verify_consent_token(token["token_id"], "RESEARCHER_1", "DATASET_42")
        self.assertTrue(is_valid)

        # Warrant de-anonymization
        mapping = {"PSEUDO_ABC": "REAL_SUSPECT_007"}
        ok_deanonym, res_deanonym = auth.authorize_de_anonymization("PSEUDO_ABC", mapping, "WARRANT_MUNICIPAL_2026")
        self.assertTrue(ok_deanonym)
        self.assertIn("REAL_SUSPECT_007", res_deanonym)
        print(" [✓] Regulatory Authority & Automated Consent Manager verified.")

    def test_10_metrics_evaluation(self):
        evaluator = DualBlockchainMetricsEvaluator()
        evaluator.record_attack_classification(1, 1, 0.94, 2.1)
        evaluator.record_attack_classification(0, 0, 0.15, 1.4)
        evaluator.record_unauthorized_access(detected=True)
        evaluator.record_blockchain_delays(1.1, 0.9, 32.0)
        evaluator.record_network_transmission(52.0, dropped=False)
        evaluator.record_computational_cost(6.1, 138.0)
        evaluator.blockchain_throughput_tps = 480.0

        m = evaluator.compute_all_metrics()
        self.assertEqual(m["Accuracy"], 1.0)
        self.assertEqual(m["Precision"], 1.0)
        self.assertEqual(m["Recall"], 1.0)
        self.assertEqual(m["F1_Score"], 1.0)
        self.assertIn("Blockchain_Transaction_Throughput_TPS", m)
        self.assertIn("Data_Integrity_Verification_Time_ms", m)
        print(" [✓] 15-Metric Academic Performance Evaluator verified.")


if __name__ == "__main__":
    print("=" * 80)
    print("RUNNING DUAL-BLOCKCHAIN CROWDSOURCING UNIT & SYSTEM TEST SUITE")
    print("=" * 80)
    suite = unittest.TestLoader().loadTestsFromTestCase(TestDualBlockchainCrowdsourcing)
    runner = unittest.TextTestRunner(verbosity=1)
    res = runner.run(suite)
    if res.wasSuccessful():
        print("\n[★★★] ALL 10 TEST SUITES PASSED FLAWLESSLY! [★★★]")
    else:
        print("\n[!] Test failures detected.")
        sys.exit(1)
