"""
Local-Node f-Differential Privacy (f-DP) Module.
Implements Gaussian Differential Privacy (mu-GDP) and trade-off function f(alpha)
for continuous local data perturbation with optimal privacy-utility balancing.
"""

import math
import numpy as np
from typing import Dict, Any, Tuple, Optional
from scipy.stats import norm
from config.system_config import FDifferentialPrivacyConfig


class LocalNodeFDifferentialPrivacy:
    """
    Local-node f-Differential Privacy (f-DP) mechanism.
    Perturbs crowdsourced sensing vectors at the edge worker node prior to transmission
    to guarantee rigorous privacy under Gaussian trade-off function guarantees.
    """
    def __init__(self, config: Optional[FDifferentialPrivacyConfig] = None, seed: int = 42):
        self.config = config or FDifferentialPrivacyConfig()
        self.rng = np.random.RandomState(seed)

        self.epsilon = self.config.epsilon
        self.delta = self.config.delta
        self.sensitivity = self.config.sensitivity
        self.clipping_bound = self.config.clipping_bound

        # Calibrate mu for Gaussian Differential Privacy (mu-GDP)
        self.mu = self._compute_mu_from_eps_delta(self.epsilon, self.delta)
        # Noise standard deviation sigma = Delta_2 / mu
        self.sigma = self.sensitivity / (self.mu + 1e-6)

    @staticmethod
    def _compute_mu_from_eps_delta(eps: float, delta: float) -> float:
        """
        Solves for parameter mu in mu-GDP corresponding to (eps, delta)-DP:
        delta = Phi(-eps/mu + mu/2) - exp(eps) * Phi(-eps/mu - mu/2)
        Approximation: mu ~= sqrt(2 * (exp(eps) - 1)) or Balle-Wang bounds.
        """
        if delta <= 0:
            delta = 1e-6
        # Fast numerical approximation for mu
        # Using standard analytic relation: eps ~= mu * sqrt(2 * ln(1/delta)) - mu^2 / 2
        # Or inverse Gaussian:
        mu_approx = math.sqrt(2.0 * math.log(1.25 / delta)) / max(0.1, eps)
        # Clamp to realistic GDP bounds
        return float(np.clip(1.0 / max(0.1, mu_approx), 0.25, 4.0))

    def trade_off_function(self, alpha: float) -> float:
        """
        Computes the theoretical f-DP trade-off function f_mu(alpha):
        f_mu(alpha) = Phi(Phi^{-1}(1 - alpha) - mu)
        Maps Type I error alpha to minimum Type II error beta.
        """
        alpha_clamped = np.clip(alpha, 1e-6, 1.0 - 1e-6)
        inv_phi = norm.ppf(1.0 - alpha_clamped)
        beta = norm.cdf(inv_phi - self.mu)
        return float(np.clip(beta, 0.0, 1.0))

    def clip_l2_norm(self, data_vector: np.ndarray) -> np.ndarray:
        """Enforces L2 sensitivity bound by clipping vectors exceeding threshold."""
        l2_norm = float(np.linalg.norm(data_vector))
        if l2_norm > self.clipping_bound:
            return data_vector * (self.clipping_bound / l2_norm)
        return np.copy(data_vector)

    def perturb_sensing_data(self, raw_sensing_data: np.ndarray) -> Tuple[np.ndarray, Dict[str, float]]:
        """
        Applies local-node f-DP perturbation:
        1. L2 Sensitivity clipping
        2. Calibrated Gaussian noise addition: N(0, sigma^2 * I)
        Returns:
            (perturbed_vector, privacy_metrics_dict)
        """
        clipped = self.clip_l2_norm(raw_sensing_data)
        noise = self.rng.normal(loc=0.0, scale=self.sigma, size=clipped.shape)
        perturbed = clipped + noise

        # Calculate empirical utility metrics
        mse = float(np.mean((raw_sensing_data - perturbed) ** 2))
        signal_power = float(np.mean(raw_sensing_data ** 2))
        snr_db = float(10.0 * math.log10(signal_power / (mse + 1e-8))) if signal_power > 0 else 0.0

        metrics = {
            "epsilon": self.epsilon,
            "delta": self.delta,
            "mu_gdp": round(self.mu, 4),
            "noise_sigma": round(self.sigma, 4),
            "mse_distortion": round(mse, 4),
            "snr_db": round(snr_db, 2)
        }
        return perturbed, metrics

    def compute_privacy_utility_curve(self, epsilons: Optional[np.ndarray] = None) -> Dict[str, Any]:
        """Generates trade-off curve across varying privacy budgets."""
        if epsilons is None:
            epsilons = np.linspace(0.2, 3.0, 15)

        mses = []
        snrs = []
        mus = []

        dummy_signal = np.array([25.0, 60.0, 1013.2, 45.0, 500.0]) # Environmental sensor vector

        for ep in epsilons:
            mu_val = self._compute_mu_from_eps_delta(ep, self.delta)
            sigma_val = self.sensitivity / (mu_val + 1e-6)
            noise = self.rng.normal(0, sigma_val, size=dummy_signal.shape)
            pert = dummy_signal + noise
            mse = float(np.mean((dummy_signal - pert) ** 2))
            snr = float(10.0 * math.log10(np.mean(dummy_signal**2) / (mse + 1e-8)))
            mses.append(mse)
            snrs.append(snr)
            mus.append(mu_val)

        return {
            "epsilons": epsilons.tolist(),
            "mses": mses,
            "snrs": snrs,
            "mus": mus
        }
